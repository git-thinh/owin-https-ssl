﻿namespace ModelBinding.Web.Models
{
    public class LocationInfo
    {
        public int X { get; set; }
        public int Y { get; set; }
    }
}